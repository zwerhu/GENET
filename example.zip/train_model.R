argv <- commandArgs(trailingOnly = TRUE)
source("CMC_CV_elasticNet2_training_bezier.R")
study <- argv[1]
expression_RDS <- argv[2]
geno_file <- argv[3]
gene_annot_RDS <- argv[4]
snp_annot_RDS <- argv[5]
snp_prior_RDS<-argv[6]
n_k_folds <- as.numeric(argv[7])
alpha <- as.numeric(argv[8])
out_dir <- argv[9]
chrom <- argv[10]
snpset <- argv[11]
window <- as.numeric(argv[12])

TW_CV_model(expression_RDS, geno_file, gene_annot_RDS, snp_annot_RDS,snp_prior_RDS, 5, n_k_folds, alpha, out_dir, study, chrom, snpset, window)
