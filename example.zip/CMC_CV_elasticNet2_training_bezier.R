# GENET scripts:
# Adapted from PrediXcan pipeline (https://github.com/hakyim/PrediXcan)
# Acknowledgments to Scott Dickinson, Alvaro Barbeira, and Hae Kyung Im for kindly help



suppressMessages(library(glmnet))
suppressMessages(library(methods))
suppressMessages(library(dplyr))
suppressMessages((library(reshape2)))


"%&%" <- function(a,b) paste(a, b, sep = "")

# randomly generate fold groupings, for comparison between GENET and PrediXcan, need to fix the splittings and 
# give same groupings to them
# is good for groupings that are irrelevant for comparisons between two models
generate_fold_ids <- function(n_samples, n_folds=10) {
  n <- ceiling(n_samples / n_folds)
  fold_ids <- rep(1:n_folds, n)
  sample(fold_ids[1:n_samples])
}

calc_R2 <- function(y, y_pred) {
  tss <- sum(y**2)
  rss <- sum((y - y_pred)**2)
  1 - rss/tss
}

# This is nested_cv_ENet for Genet with epigenomic prior mappings
# pfac vector contains incoporated penalty factors that comes from priors, other parameters are same to PrediXcan
nested_cv_elastic_net_perf <- function(x, y, pfac,  n_samples, n_train_test_folds, n_k_folds, alpha) {
  # Gets performance estimates for k-fold cross-validated elastic-net models.
  # Splits data into n_train_test_folds disjoint folds, roughly equal in size,
  # and for each fold, calculates a n_k_folds cross-validated elastic net model. Lambda parameter is
  # cross validated. Then get performance measures for how the model predicts on the hold-out
  # fold. Get the coefficient of determination, R^2, and a p-value, where the null hypothesis
  # is there is no correlation between prediction and observed.
  #
  # The mean and standard deviation of R^2 over all folds is then reported, and the p-values
  # are combined using Fisher's method.
  rmse_folds <- rep(0, n_train_test_folds)
  R2_folds <- rep(0, n_train_test_folds)
  corr_folds <- rep(0, n_train_test_folds)
  zscore_folds <- rep(0, n_train_test_folds)
  pval_folds <- rep(0, n_train_test_folds)
  # Outer-loop split into training and test set.
  # train_test_fold_ids <- generate_fold_ids(n_samples, n_folds=n_train_test_folds)
  # above groupings are random: use preset good groupings and get fixed
  # on minerva:
  #groupings <- read.table('/sc/orga/projects/roussp01a/Wen/PredictDB/PredictDBPipeline/data/input/genotypes/genoCMCgroup.txt',header=TRUE,stringsAsFactors=FALSE)
  groupings <- read.table('/Users/wenzhang/Desktop/GENET_Bit/example/genoCMCgroup.txt',header=TRUE,stringsAsFactors=FALSE)
  rownames(groupings)<-groupings$V1
  # get the preset fivefold ids:
  train_test_fold_ids <- groupings[rownames(y),'fivefold']
  y=as.vector(y)
  for (test_fold in 1:n_train_test_folds) {
    train_idxs <- which(train_test_fold_ids != test_fold)
    test_idxs <- which(train_test_fold_ids == test_fold)
    x_train <- x[train_idxs, ]
    y_train <- y[train_idxs]
    x_test <- x[test_idxs, ]
    y_test <- y[test_idxs]
    # Inner-loop - split up training set for cross-validation to choose lambda.
    # this is not related to the adjusted R2 between two models, preset cv ids are not passed  
    cv_fold_ids <- generate_fold_ids(length(y_train), n_k_folds)
    y_pred <- tryCatch({
      # Fit model with training data.
      # go with penalty factors, which come from priors
      fit <- cv.glmnet(x_train, y_train, penalty.factor=pfac, nfolds = n_k_folds, alpha = alpha, type.measure='mse', foldid = cv_fold_ids)
      # Predict test data using model that had minimal mean-squared error in cross validation.
      predict(fit, x_test, s = 'lambda.min')},
      # if the elastic-net model did not converge, predict the mean of the y_train (same as all non-intercept coef=0)
      error = function(cond) rep(mean(y_train), length(y_test)))
    R2_folds[test_fold] <- calc_R2(y_test, y_pred)
    ## get rmse
    res <- summary(lm(y_test~y_pred))
    #adjR2_folds[test_fold] <- res$adj.r.squared
    rmse_folds[test_fold] <-sqrt(1-res$r.squared)*(res$sigma)
    # Get p-value for correlation test between predicted y and actual y.
    # If there was no model, y_pred will have var=0, so cor.test will yield NA.
    # In that case, give a random number from uniform distribution, which is what would
    # usually happen under the null.
    corr_folds[test_fold] <- ifelse(sd(y_pred) != 0, cor(y_pred, y_test), 0)
    zscore_folds[test_fold] <- atanh(corr_folds[test_fold])*sqrt(length(y_test) - 3) # Fisher transformation
    pval_folds[test_fold] <- ifelse(sd(y_pred) != 0, cor.test(y_pred, y_test)$p.value, runif(1))
  }
  rmse_avg <- mean(rmse_folds)
  R2_avg <- mean(R2_folds)
  R2_sd <- sd(R2_folds)
  rho_avg <- mean(corr_folds)
  rho_se <- sd(corr_folds)
  rho_avg_squared <- rho_avg**2
  # Stouffer's method for combining z scores.
  zscore_est <- sum(zscore_folds) / sqrt(n_train_test_folds)
  zscore_pval <- 2*pnorm(abs(zscore_est), lower.tail = FALSE)
  # Fisher's method for combining p-values: https://en.wikipedia.org/wiki/Fisher%27s_method
  pval_est <- pchisq(-2 * sum(log(pval_folds)), 2*n_train_test_folds, lower.tail = F)
  list(rmse_avg=rmse_avg,R2_avg=R2_avg, R2_sd=R2_sd, pval_est=pval_est, rho_avg=rho_avg, rho_se=rho_se, rho_zscore=zscore_est, rho_avg_squared=rho_avg_squared, zscore_pval=zscore_pval)
}



# the file snp_prior_RDS stores qtlBHM priors from epigenomic information
TW_CV_model <- function(expression_RDS, geno_file, gene_annot_RDS, snp_annot_RDS,snp_prior_RDS, n_train_test_folds, n_k_folds, alpha, out_dir, tis, chrom, snpset, window, seed = NA) {
  expression <- readRDS(expression_RDS)
  class(expression) <- 'numeric'
  # row.names should be the first column name in genotype file
  genotype <- read.table(geno_file, header = TRUE, row.names = 'rsid', stringsAsFactors = FALSE)
  genotype <- genotype[,-1] # delete chr column
  genotype <- genotype[,-1] # then delete Pos column
  # Transpose genotype for glmnet
  genotype <- t(genotype)
  gene_annot <- readRDS(gene_annot_RDS)
  gene_annot <- subset(gene_annot, gene_annot$chr == chrom)
  snp_annot <- readRDS(snp_annot_RDS)
  rownames(snp_annot)<-snp_annot$rsid
  snp_prior<-readRDS(snp_prior_RDS)
  ## well processed snp priors
  #snp_prior=subset(snp_prior,snp_prior$RSID_dbSNP137!=0)
  a<-intersect(rownames(genotype),rownames(expression))
  genotype<-genotype[a,]
  expression<-expression[a,]
  rownames(gene_annot) <- gene_annot$gene_id
  # Subset expression data to only include genes with gene_info
  expression <- expression[, intersect(colnames(expression), rownames(gene_annot))]
  exp_samples <- rownames(expression)
  exp_genes <- colnames(expression)
  n_samples <- length(exp_samples)
  n_genes <- length(exp_genes)
  seed <- ifelse(is.na(seed), sample(1:1000000, 1), seed)
  set.seed(seed)
  log_df <- data.frame(chrom, n_genes, seed, alpha)
  colnames(log_df) <- c('chr', 'n_genes', 'seed_for_cv', 'alpha')
  write.table(log_df, file = out_dir %&% tis %&% '_chr' %&% chrom %&% '_elasticNet_model_log.txt', quote = FALSE, row.names = FALSE, sep = "\t")
  
  workingbest <- out_dir %&% "working_TW_" %&% tis %&% "_exp_" %&% n_k_folds %&% "-foldCV_elasticNet_alpha" %&% alpha %&% "_" %&% snpset %&% "_chr" %&% chrom %&% ".txt"
  weightcol <- c("gene","gene_name","gene_start","gene_end","strand","chr","pos","distTSS","rsid","Annotation","Prior","Penalty_factor","ref","alt","beta","alpha")
  workingweight <- out_dir %&% "TW_" %&% tis %&% "_elasticNet_alpha" %&% alpha %&% "_" %&% snpset %&% "_weights_chr" %&% chrom %&% ".txt"
  write(weightcol, file = workingweight, ncol = 16, sep = "\t")
  
  covariance_out <- out_dir %&% tis %&% '_chr' %&% chrom %&% '_snpset_' %&% snpset %&% '_alpha_' %&% alpha %&% "_covariances.txt"
  # exp_genes<-intersect(exp_genes,snp_prior$V5)
  resultsarray <- array(0, c(length(exp_genes), 26))
  dimnames(resultsarray)[[1]] <- exp_genes
  resultscol <- c('gene_id', 'gene_name', 'gene_type', 'alpha', 'n_snps_in_window', 'n_snps_in_model', 'lambda_min_mse',
                  'adjust_R2','rmse', 'test_R2_avg', 'test_R2_sd', 'cv_R2_avg', 'cv_R2_sd', 'in_sample_R2',
                  'nested_cv_fisher_pval', 'rho_avg', 'rho_se', 'rho_zscore', 'rho_avg_squared', 'zscore_pval',
                  'cv_rho_avg', 'cv_rho_se', 'cv_rho_avg_squared', 'cv_zscore_est', 'cv_zscore_pval', 'cv_pval_est')
  #c("gene", "alpha", "cvm", "lambda.iteration", "lambda.min", "n.snps", "R2","adjusted.R2", "pval","rmse", "genename")
  dimnames(resultsarray)[[2]] <- resultscol
  write(resultscol, file = workingbest, ncolumns = 26, sep = "\t")
  
  for (i in 1:length(exp_genes)) {
    cat(i, "/", length(exp_genes), "\n")
    gene <- exp_genes[i]
    # Reduce genotype data to only include SNPs within specified window of gene.
    gene_name <- gene_annot$gene_name[gene_annot$gene_id == gene]
    gene_type <- filter(gene_annot, gene_id == gene)$gene_type
    
    geneinfo <- gene_annot[gene,]
    start <- geneinfo$start - window
    end <- geneinfo$end + window
    genetype<-geneinfo$gene_type
    # Pull cis-SNP info
    cissnps <- subset(snp_annot, snp_annot$pos >= start & snp_annot$pos <= end)
    # Pull cis-SNP genotypes
    # post1<-subset(snp_prior,snp_prior$V5==gene)
    cissnp1index=intersect(colnames(genotype),cissnps$rsid)
    rownames(snp_prior)<-snp_prior$RSID_dbSNP137
    index1<-intersect(cissnp1index,snp_prior$RSID_dbSNP137)
    cisgenos <- genotype[,cissnp1index, drop = FALSE]
    prior_penal<-snp_prior[cissnp1index,]
    rownames(prior_penal)<-cissnp1index
    prior_penal[,3]=rep(0,length(prior_penal[,3]))
    prior_penal[index1,3]=snp_prior[index1,3]
    # rownames(prior_penal)<- rownames(snp_prior[index1,])
    # Reduce cisgenos to only include SNPs with at least 1 minor allele in dataset
    cm <- colMeans(cisgenos, na.rm = TRUE)
    minorsnps <- subset(colMeans(cisgenos), cm > 0 & cm < 2)
    minorsnps <- names(minorsnps)
    cisgenos <- cisgenos[,minorsnps, drop = FALSE]
    # get the priors of all snps in the subset
    prior_penal<-prior_penal[minorsnps,]
    prior_info=prior_penal
    prior_penal<-prior_penal[,3]
    pfac=prior_penal
    
    if (ncol(cisgenos) < 2) {
      # Need 2 or more cis-snps for glmnet.
      bestbetas <- data.frame()
    } else {
      # Pull expression data for gene
      exppheno <- expression[,gene]
      # Scale for fastLmPure to work properly
      exppheno <- scale(exppheno, center = TRUE, scale = TRUE)
      exppheno[is.na(exppheno)] <- 0
      rownames(exppheno) <- rownames(expression)
      # simulation values   
      CMCx2=4.69250216
      # real max prior
      x2=4.75039291
      y2=0.7
      x1=1.9*x2/CMCx2
      y1=0.7
      
      # get penalty factors according to rescaling
      for (j in 1:length(pfac)) {
        pfac[j]=Re((1+y2-2*y1)/((x2-2*x1)^2)*(2*x1^2+pfac[j]*(x2-2*x1)-2*x1*(x1^2+pfac[j]*(x2-2*x1))^0.5)+(y1-1)/(x2-2*x1)*(-2*x1+2*(x1^2+pfac[j]*(x2-2*x1))^0.5)+1)
      }
      prior_info[,6]=pfac
      # Although for PrediXcan, no priors are used, the information of each SNP including the prior is contained in the PredictDB
      colnames(prior_info)<-c('Chr', 'Pos','Prior', 'RSID_dbSNP137','Annotation','penalty_factor')
      
      #perf_measures <- nested_cv_elastic_net_perf(as.matrix(cisgenos), as.vector(exppheno),pfac, n_samples, n_train_test_folds, n_k_folds, alpha)
      # need the sample IDs: pass exppheno into the function
      # to get performance evaluations adapted from PrediXcan
      perf_measures <- nested_cv_elastic_net_perf(as.matrix(cisgenos), (exppheno),pfac, n_samples, n_train_test_folds, n_k_folds, alpha)
      R2_avg <- perf_measures$R2_avg
      rmse_avg <- perf_measures$rmse_avg
      R2_sd <- perf_measures$R2_sd
      pval_est <- perf_measures$pval_est
      rho_avg <- perf_measures$rho_avg
      rho_se <- perf_measures$rho_se
      rho_zscore <- perf_measures$rho_zscore
      rho_avg_squared <- perf_measures$rho_avg_squared
      zscore_pval <- perf_measures$zscore_pval
      
      # Fit on all data
      # random groupings, need to import fixed groupings for both GENET and PrediXcan
      #cv_fold_ids <- generate_fold_ids(length(exppheno), n_k_folds)
      # give fixed and good groupings: to compare performance of PrediXcan and GENET
      # The grouping file:
      #groupings <- read.table('/sc/orga/projects/roussp01a/Wen/PredictDB/PredictDBPipeline/data/input/genotypes/genoCMCgroup.txt',header=TRUE,stringsAsFactors=FALSE)
      groupings <- read.table('/Users/wenzhang/Desktop/GENET_Bit/example/genoCMCgroup.txt',header=TRUE,stringsAsFactors=FALSE)
      rownames(groupings)<-groupings$V1
      # get the preset 10-fold CV grouping ids:
      cv_fold_ids <- groupings[rownames(exppheno),'grouping']
      # Run Cross-Validation, the following inputs for both PrediXcan and GENET are exactly the same, except the priors(penalty.factor) for GENET
      fit <- tryCatch(cv.glmnet(as.matrix(cisgenos),as.vector(exppheno),penalty.factor=pfac, nfolds = n_k_folds, alpha = 0.5, type.measure='mse', foldid = cv_fold_ids, keep = TRUE),
                      error = function(cond) {message('Error'); message(geterrmessage()); list()})
      if (length(fit) > 0) {
        cv_R2_folds <- rep(0, n_k_folds)
        cv_corr_folds <- rep(0, n_k_folds)
        cv_zscore_folds <- rep(0, n_k_folds)
        cv_pval_folds <- rep(0, n_k_folds)
        best_lam_ind <- which.min(fit$cvm)
        for (j in 1:n_k_folds) {
          fold_idxs <- which(cv_fold_ids == j)
          adj_expr_fold_pred <- fit$fit.preval[fold_idxs, best_lam_ind]
          cv_R2_folds[j] <- calc_R2(exppheno[fold_idxs], adj_expr_fold_pred)
          cv_corr_folds[j] <- ifelse(sd(adj_expr_fold_pred) != 0, cor(adj_expr_fold_pred, exppheno[fold_idxs]), 0)
          cv_zscore_folds[j] <- atanh(cv_corr_folds[j])*sqrt(length(exppheno[fold_idxs]) - 3) # Fisher transformation
          cv_pval_folds[j] <- ifelse(sd(adj_expr_fold_pred) != 0, cor.test(adj_expr_fold_pred, exppheno[fold_idxs])$p.value, runif(1))
        }
        cv_R2_avg <- mean(cv_R2_folds)
        cv_R2_sd <- sd(cv_R2_folds)
        adj_expr_pred <- predict(fit, as.matrix(cisgenos), s = 'lambda.min')
        training_R2 <- calc_R2(exppheno, adj_expr_pred)
        cv_rho_avg <- mean(cv_corr_folds)
        cv_rho_se <- sd(cv_corr_folds)
        cv_rho_avg_squared <- cv_rho_avg**2
        # Stouffer's method for combining z scores.
        cv_zscore_est <- sum(cv_zscore_folds) / sqrt(n_k_folds)
        cv_zscore_pval <- 2*pnorm(abs(cv_zscore_est), lower.tail = FALSE)
        cv_pval_est <- pchisq(-2 * sum(log(cv_pval_folds)), 2*n_k_folds, lower.tail = F)
        if (fit$nzero[best_lam_ind] > 0) {
          # number of predictors
          n_fit=fit$nzero[best_lam_ind]
          # Discuss with Yungil: use R2 of correlation between predicted and observed expression values for all samples:
          y_all=predict(fit, as.matrix(cisgenos), s = 'lambda.min')
          # correlation R2
          corr_R=ifelse(sd(y_all) != 0, cor(y_all, exppheno),0)
          corr_R2=corr_R**2
          # adjusted correlation R2
          adj_R2=1-(1-corr_R2)*(n_samples-1)/(n_samples-1-n_fit)
          weights <- fit$glmnet.fit$beta[which(fit$glmnet.fit$beta[,best_lam_ind] != 0), best_lam_ind]
          weighted_snps <- names(fit$glmnet.fit$beta[,best_lam_ind])[which(fit$glmnet.fit$beta[,best_lam_ind] != 0)]
          # Output best shrunken betas for PrediXcan
          bestweightlist <- weighted_snps
          bestweightinfo <- snp_annot[bestweightlist,]
          # get information of priors
          bestpriorinfo<-prior_info[bestweightlist,]
          # calculate distTSS
          if (geneinfo$strand=='-') {
            bestweightinfo[,6]=geneinfo$end-bestweightinfo[,2] }
          if (geneinfo$strand=='+') {
            bestweightinfo[,6]=bestweightinfo[,2]-geneinfo$start }
          colnames(bestweightinfo)<-c('chr', 'pos', 'refAllele', 'effectAllele','rsid','distTSS')
          weighttable <- cbind(bestweightinfo,bestpriorinfo[,3:6])
          weighttable$weight=weights
          weightfile <- weighttable[,c("chr","pos","distTSS","rsid","Annotation","Prior","penalty_factor","refAllele","effectAllele","weight")]
          weightfile$gene=gene
          weightfile$gene_name=geneinfo$gene_name
          weightfile$gene_start=geneinfo$start
          weightfile$gene_end=geneinfo$end
          weightfile$strand=geneinfo$strand
          
          weightfile$alpha=alpha
          weightfile<-weightfile[,c('gene','gene_name','gene_start','gene_end','strand','chr','pos','distTSS','rsid','Annotation','Prior','penalty_factor','refAllele','effectAllele','weight','alpha')]
          write(t(weightfile), file = workingweight, ncolumns = 16,append = TRUE, sep = '\t')
          write_covariance(gene, cisgenos, weighttable[,"rsid"], weighttable[,"rsid"],covariance_out)
          resultsarray[gene,]  <- c(gene, gene_name, gene_type, alpha, ncol(cisgenos), fit$nzero[best_lam_ind], fit$lambda[best_lam_ind],adj_R2,rmse_avg, R2_avg, R2_sd, cv_R2_avg, cv_R2_sd, training_R2, pval_est,
                                    rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval, cv_rho_avg, cv_rho_se, cv_rho_avg_squared, cv_zscore_est, cv_zscore_pval, cv_pval_est)
        } else {
          resultsarray[gene,] <- c(gene, gene_name, gene_type, alpha, ncol(cisgenos), 0, fit$lambda[best_lam_ind],0,rmse_avg, R2_avg, R2_sd,
                                   cv_R2_avg, cv_R2_sd, training_R2, pval_est, rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval,
                                   cv_rho_avg, cv_rho_se, cv_rho_avg_squared, cv_zscore_est, cv_zscore_pval, cv_pval_est)
        }
        
        
      }else {
        resultsarray[gene,] <- c(gene, gene_name, gene_type, alpha, ncol(cisgenos), 0, NA, NA,rmse_avg,R2_avg, R2_sd, NA, NA, NA, pval_est, rho_avg, rho_se, rho_zscore, rho_avg_squared, zscore_pval,
                                 NA, NA, NA, NA, NA, NA)
      }
      write(resultsarray[gene,], file = workingbest, ncolumns = 26, append = TRUE, sep = "\t")
    }
  }
  write.table(resultsarray,file=out_dir %&% "TW_" %&% tis %&% "_chr" %&% chrom %&% "_exp_" %&% n_k_folds %&% "-foldCV_elasticNet_alpha" %&% alpha %&% "_" %&% snpset %&% ".txt",quote=F,row.names=F,sep="\t")
  
}
write_covariance <- function(gene, cisgenos, model_rsids, model_varIDs, covariance_out) {
  model_geno <- cisgenos[,model_varIDs, drop=FALSE]
  geno_cov <- cov(model_geno)
  cov_df <- data.frame(gene=character(),rsid1=character(),rsid2=character(), covariance=double())
  for (i in 1:length(model_rsids)) {
    for (j in i:length(model_rsids)) {
      cov_df <- rbind(cov_df, data.frame(gene=gene,rsid1=model_rsids[i], rsid2=model_rsids[j], covariance=geno_cov[i,j]))
    }
  }
  write.table(cov_df, file = covariance_out, append = TRUE, quote = FALSE, col.names = FALSE, row.names = FALSE, sep = " ")
}

